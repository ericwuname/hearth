#!/usr/bin/env bash
export PATH="$HOME/.cargo/bin:$PATH"
echo "--- rebuild post-change build (5b45c57) + identity archive ---"
cd /home/wutao/codex-r6
cargo build --release -p codex-cli 2>&1 | tail -1
export HEARTH_BIN=/home/wutao/codex-r6/target/release/hearth
$HEARTH_BIN --version
md5sum $HEARTH_BIN
cd /home/wutao/regress-run
RUNNER=/home/wutao/codex-r6/regression/run-regression.sh
flock /tmp/hr-regress.lock bash -c "
  for i in 1 2 3; do
    bash $RUNNER --arm B --extra-args '--approve-within session' > /home/wutao/regress-run/r8-post${i}-armB-blind.log 2>&1
    bash $RUNNER --arm A --extra-args '--approve-within session' > /home/wutao/regress-run/r8-post${i}-armA-blind.log 2>&1
  done
  bash $RUNNER --arm B --corpus c --extra-args '--approve-within session' > /home/wutao/regress-run/r8-postc-armB-corpusc.log 2>&1
  bash $RUNNER --arm A --corpus c --extra-args '--approve-within session' > /home/wutao/regress-run/r8-postc-armA-corpusc.log 2>&1
  echo POST_DONE > /home/wutao/regress-run/r8-post.done
"
