#!/usr/bin/env bash
pkill -f "run-regression" 2>/dev/null
pkill -f "hearth chat" 2>/dev/null
sleep 2
echo "--- engine identity (pre-change build) ---"
md5sum /usr/local/bin/hearth
/usr/local/bin/hearth --version
cd /home/wutao/regress-run
export HEARTH_BIN=/usr/local/bin/hearth
RUNNER=/home/wutao/codex-r6/regression/run-regression.sh
flock /tmp/hr-regress.lock bash -c "
  bash $RUNNER --arm B --extra-args '--approve-within session' > /home/wutao/regress-run/r8-pre1-armB-blind.log 2>&1
  bash $RUNNER --arm A --extra-args '--approve-within session' > /home/wutao/regress-run/r8-pre1-armA-blind.log 2>&1
  bash $RUNNER --arm B --extra-args '--approve-within session' > /home/wutao/regress-run/r8-pre2-armB-blind.log 2>&1
  bash $RUNNER --arm A --extra-args '--approve-within session' > /home/wutao/regress-run/r8-pre2-armA-blind.log 2>&1
  echo PRE_DONE > /home/wutao/regress-run/r8-pre.done
"
